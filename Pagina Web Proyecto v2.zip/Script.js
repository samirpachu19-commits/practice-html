document.querySelectorAll(".mySwiper").forEach((slider) => {
    new Swiper(slider, {
        slidesPerView: 1,
        spaceBetween: 30,
        speed: 250,
        loop: true,
        loopFillGroupWithBlank: true,
        navigation: {
            nextEl: slider.querySelector(".swiper-button-next"),
            prevEl: slider.querySelector(".swiper-button-prev"),
        },
        pagination: {
            el: slider.querySelector(".swiper-pagination"),
            clickable: true,
        },
        breakpoints: {
            768: {
                slidesPerView: 2,
            },
            1024: {
                slidesPerView: 3,
            },
        },
    });
});